class FeeBearer {
    static MERCHANT = "M";
    static CUSTOMER = "C";
}
class GatewayResponseCode {
    static SUCCESS = "00";
    static PENDING = "09";
}
class GatewayReturnStatus {
    static SUCCESS = "success";
    static CANCELED = "canceled";
    static FAILED = "failed";
    static PENDING = "pending";
}
class Config {
    constructor(displayType) {
        this.displayType = displayType || "modal"
    }
}
class NextPaymentGateway {
    constructor(config) {
        this.config = config
    }
    async initialize(options) {
        this.__onInitializationFailed = options.onInitializationFailed
        this.__onInitializationSuccess = options.onInitializationSuccess
        this.__onClose = options.onClose
        this.__onCancel = options.onCancel
        this.__onFailure = options.onFailure
        this.__onSuccess = options.onSuccess
        this.__returnUrl = options.returnUrl
        this.__response = {}
        this.__response.payPageLink = options.payPageLink
    }
    pay(){
        let self = this
        setTimeout(function () {
            if (self.config.displayType === "modal") {
                self.__mountModal()
            } else {
                self.__loadIframe()
            }
        }, 100)
    }
    __listenForCloseEvent() {
        let clientSdkIframe = document.getElementById("cp-frame-component")
        let self = this
        if (clientSdkIframe) {
            clientSdkIframe.onload = async function () {
                if (this.contentWindow.location) {
                    let location = clientSdkIframe.contentWindow.location.toString()
                    self.__closeIframe();
                    self.__closeModal();
                    let queryParam = self.__decodeUrl(location)
                    self.__traceid = queryParam.traceid
                    self.__status = queryParam.status
                    self.__id = queryParam.id
                    if (self.__status === GatewayReturnStatus.SUCCESS){
                        self.__executeFunction(self.__onSuccess, [self.__id, self.__traceid])
                    }else if (self.__status === GatewayReturnStatus.CANCELED){
                        self.__executeFunction(self.__onCancel, [self.__id, self.__traceid])
                    }else{
                        self.__executeFunction(self.__onFailure, [self.__id, self.__traceid])
                    }
                }
            }
        }
    }
    __loadIframe() {
        this.div = document.createElement('div');
        this.div.id = "cp-frame-component-container";
        this.div.setAttribute('style', "-webkit-overflow-scrolling: touch; overflow-y: scroll; position:fixed; left: 0; right: 0; bottom: 0; top: 0px; z-index: 1000000000;");
        this.iframe = document.createElement('iframe');
        this.iframe.src = this.__response.payPageLink;
        this.iframe.id = "cp-frame-component";
        this.iframe.setAttribute('style', "z-index: 2147483647;display: block;border: 0px none transparent; overflow-x: hidden; overflow-y: auto; visibility: visible; margin: 0px; padding: 0px; -webkit-tap-highlight-color: transparent; width: 100%; @media only screen and (max-width: 600px) {margin-bottom: 30%}; height: 110%");
        this.iframeOpen = true;
        this.div.appendChild(this.iframe);
        document.body.appendChild(this.div);
        this.__listenForCloseEvent();
    };
    __closeIframe() {
        if (this.iframeOpen) {
            if (this.iframe) {
                this.iframe.style.display = "none";
                this.iframe.style.visibility = "hidden";
                this.iframeOpen = false;
                document.body.style.overflow = "";
            }
        }
    }
    __mountModal(){
        this.div = document.createElement('div');
        this.div.id = "cp-modal-component-container";
        this.div.setAttribute('style', "display: block; position: fixed; z-index: 9999999999999999; left: 0; top: 0; width: 100%; height: 100%; overflow: none; background-color: rgba(0,0,0,0.4);");
        this.innerdiv = document.createElement('div');
        this.innerdiv.id = "cp-modal-component-content";
        this.innerdiv.setAttribute('style', "width:100%;border-radius: 10px;height: 80vh;border:1px solid #888;padding:0;margin:5% auto;background-color:#fefefe;min-height=558px;max-height=600px;max-width:400px;border-radius:10px");
        this.iframe = document.createElement('iframe');
        this.iframe.src = this.__response.payPageLink;
        this.iframe.id = "cp-frame-component";
        this.iframe.setAttribute('style', "z-index: 2147483647;display: block;border: 0px none transparent;border-radius: 10px; overflow-x: hidden; overflow-y: auto; visibility: visible; margin: 0px; padding: 0px; -webkit-tap-highlight-color: transparent; width: 100%;margin-bottom: 30%;height:100%;");
        this.iframeOpen = true;
        this.innerdiv.appendChild(this.iframe);
        this.div.appendChild(this.innerdiv);
        document.body.appendChild(this.div);
        this.__openModal()
        this.__listenForCloseEvent();
    }
    __closeModal(){
        let modal = document.getElementById("cp-modal-component-container");
        if (modal) modal.remove();
    }
    __openModal(){
        let modal = document.getElementById("cp-modal-component-container");
        modal.style.display = "block";
    }
    __executeFunction(fun, data) {
        let element = document.getElementById('cp-frame-component-container');
        if (element) element.parentNode.removeChild(element);
        if (fun) {
            if (data.length > 1) fun(data[0],data[1]); else fun(data[0]);
        }
        this.__closeIframe();
    };
    __decodeUrl(e) {
        let a = {}
        for (let t, n = /[?&]([^=#]+)=([^&#]*)/g; t = n.exec(e);)
            a[t[1]] = t[2];
        return a
    }
}